AF-group-project-final

after clone or download project, open the project directory using command line,
and type npm install