package test;

import java.sql.SQLException;

public class MyTest {

	public static void main(String[] args) throws SQLException {
		// List<Employee> HAt=new ArrayList();
		//
		// //out only projects
		// HAt= new EmployeeService().getSumSalariesOnProject();
		// for(Employee em : HAt){
		// System.out.print(em.getProject_id()+"-");
		// System.out.print(em.getEmp_salary()+"-");
		// System.out.println(em.getEmp_name());
		// }
		// System.out.println(HAt.toString());
		/* Result set will deliver you an TooManyResultException---- */
		// ResultSet nz= new EmployeeService().getSumSalariesOnProject();
		// while(nz.next()){
		// System.out.println(nz.getString("project_id")+" "+
		// nz.getDouble("Total Salary") +" "+nz.getInt("NumberOfEmployess"));
		//
		// }

	}
}
