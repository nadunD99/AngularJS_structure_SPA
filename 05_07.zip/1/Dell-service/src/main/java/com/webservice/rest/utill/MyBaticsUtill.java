package com.webservice.rest.utill;

import java.io.IOException;
import java.io.Reader;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.codehaus.jackson.map.ObjectMapper;

public class MyBaticsUtill {
	//***************************************************************************    
	private static SqlSessionFactory factory;
	static {
		Reader reader = null;
		try {
			reader = Resources.getResourceAsReader("mybatis-config.xml");
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
		factory = new SqlSessionFactoryBuilder().build(reader);
	}
    //*****************************************************************************
	public static SqlSessionFactory getSqlSessionFactory() {
		return factory;
	}
	//*****************************************************************************
	
	public static String ConvertJavaObject2Json(Object object) {
		String jsonStr = "empty";
		try {
			 ObjectMapper mapperObj = new ObjectMapper();
		     jsonStr = mapperObj.writeValueAsString(object);
		} catch (Exception e) {
			e.printStackTrace();
		}
       
        return jsonStr;
		}
	//****************************************************************************l̥
}
