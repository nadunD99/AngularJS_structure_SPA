package com.webservice.rest.Testing;

import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Assert;
import com.webservice.rest.model.Project;
import com.webservice.rest.service.ProjectService;

public class ProjectTest {
	private static ProjectService projectService;

	@BeforeClass
	public static void setup() {
		projectService = new ProjectService();
	}

	@AfterClass
	public static void teardown() {
		projectService = null;
	}

	@Test
	public void testGetEmployeeById() {
		Project P = projectService.getProjectById("CART1212");
		Assert.assertNotNull(P);
		System.out.println(P);
	}

	@Test
	public void testGetAllProjects() {
		List<Project> All = projectService.getAllProjects();
		Assert.assertNotNull(All);
		for (Project P : All) {
			System.out.println(All);
		}
	}

	@Test
	public void testInsertProject() {
		Project project = new Project();
		project.setProject_id("CSVB6789");
		project.setProject_name("GOLD-STANDED-WHEY");
		project.setProject_location("NewZeland");
		project.setPManager_id(13);
		projectService.insertProject(project);
		Assert.assertTrue(project.getProject_id() != null);
		Project createdP = projectService.getProjectById(project.getProject_id());
		Assert.assertNotNull(createdP);
		Assert.assertEquals(project.getProject_id(), createdP.getProject_id());
		Assert.assertEquals(project.getProject_name(), createdP.getProject_name());
		Assert.assertEquals(project.getProject_id(), createdP.getProject_id());
		Assert.assertEquals(project.getProject_location(), createdP.getProject_location());
		System.out.println(createdP.toString());
	}

	@Test
	public void testUpdateProject() {
		Project project = projectService.getProjectById("CART1245");
		System.out.println("Before update : " + project.toString());
		project.setProject_name("FashionBUG-FLASH-sale");
		project.setProject_location("SL-Kandy1");
		project.setPManager_id(11);
		projectService.updateProject(project);
		// After Update
		Project updatedProject = projectService.getProjectById("CART1245");
		Assert.assertEquals(project.getProject_name(), updatedProject.getProject_name());
		Assert.assertEquals(project.getProject_location(), updatedProject.getProject_location());
		Assert.assertEquals(project.getPManager_id(), updatedProject.getPManager_id());
		System.out.println("Before update : " + updatedProject.toString());
	}

	@Test
	public void testDeleteProject() {
		Project project = projectService.getProjectById("CART1245");
		projectService.deleteProject(project.getProject_id());
		System.out.println("DELETED---> " + project.toString());
		Project deletedProject = projectService.getProjectById("CART1245");
		Assert.assertNull(deletedProject);
		System.out.println(projectService.getAllProjects());
	}
}