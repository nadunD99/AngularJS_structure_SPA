package com.webservice.rest.mapping;

import java.util.List;

import com.webservice.rest.model.Employee;
import com.webservice.rest.model.ProjectManager;

public interface ProjectManagerMapper {

	public List<ProjectManager> getAllManagers();

	public ProjectManager getManagerById(int manager);

	public void deleteManager(int manager);

	public void insertManager(ProjectManager manager);

	public void updateManager(ProjectManager manager);
	
	public List<Employee> getEmployeeByManagerId(int manager);
}
