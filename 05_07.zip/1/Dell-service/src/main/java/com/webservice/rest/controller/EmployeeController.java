package com.webservice.rest.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.webservice.rest.model.Employee;
import com.webservice.rest.service.EmployeeService;
import com.webservice.rest.utill.MyBaticsUtill;

@Path("/employee")
public class EmployeeController {

	@GET
	@Path("/getAllEmployee")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getEveryone() {
		List<Employee> employees = new EmployeeService().getAllEmployees();
		return Response.ok(200).entity(MyBaticsUtill.ConvertJavaObject2Json(employees)).build();
	}

	@GET
	@Path("getEmployee/{empId}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response getEmployeeOnId(@PathParam("empId") int EmployeeNo) {
		Employee projectEmployee = new Employee();
		projectEmployee = new EmployeeService().getEmployeeById(EmployeeNo);
		return Response.ok(200).entity(MyBaticsUtill.ConvertJavaObject2Json(projectEmployee)).build();
	}

	@GET
	@Path("/{projectId}/allEmployee")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response getEmployeesOnProject(@PathParam("projectId") String ProjectId) {
		List<Employee> employees = new EmployeeService().getAllEmployeeInProject(ProjectId);
		return Response.ok(200).entity(MyBaticsUtill.ConvertJavaObject2Json(employees)).build();
	}
	
	@POST
	@Path("/addEmployee")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response insertEmployee(Employee employee) {
		new EmployeeService().insertEmployee(employee);
		return Response.ok(201).entity("Insert:" + employee.toString() + " ---------Successfully Inserted----------- ")
				.build();
	}

	@DELETE
	@Path("/DELETE/{id}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response deleteEmployee(@PathParam("id") int userId) {
		Employee Deleted = new EmployeeService().getEmployeeById(userId);
		new EmployeeService().deleteEmployee(userId);
		return Response.ok(200).entity("Deleted:" + Deleted.toString() + " ---------Successfully Deleted----------- ")
				.build();
	}
	
	
	@PUT
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("/UPDATE/{employee}")
	public Response updateEmployee(Employee employee) {
		new EmployeeService().updateEmployee(employee);
		return Response.status(200).entity("Sucessfully Updated the Details "+MyBaticsUtill.ConvertJavaObject2Json(employee)).build();
	}
	

	@GET
	@Path("/cool")
	@Produces(MediaType.TEXT_HTML)
	public String goodmoring() {
		return "This is Employee";
	}
}

