package com.webservice.rest.mapping;

import java.sql.ResultSet;
import java.util.List;

import com.webservice.rest.model.Employee;


public interface ServiceMapper {
	
	public List<Employee> getSumSalariesOnProject();
	

}
