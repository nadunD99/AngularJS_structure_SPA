package com.webservice.rest.mapping;

import com.webservice.rest.model.Employee;

import java.sql.ResultSet;
import java.util.List;

public interface EmployeeMapper {

	public List<Employee> getAllEmployees();

	public Employee getEmployeeById(int Employee);

	public void deleteEmployee(int Employee);

	public void insertEmployee(Employee Employee);

	public void updateEmployee(Employee Employee);

	public List<Employee> getAllEmployeeInProject(String ProjectId);
	
	public List<Employee> getSumSalariesOnProject();

	}
