package com.webservice.rest.controller;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.webservice.rest.model.Project;
import com.webservice.rest.service.ProjectService;
import com.webservice.rest.utill.MyBaticsUtill;

@Path("/projects")
public class ProjectController {

	@GET
	@Path("/allProjects")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response getEveryone() {
		List<Project> project = new ProjectService().getAllProjects();
		return Response.ok(200).entity(MyBaticsUtill.ConvertJavaObject2Json(project)).build();
	}

	@GET
	@Path("/{ProjectNo}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response getProjectOnId(@PathParam("ProjectNo") String ProjectNo) {
		Project Project = new Project();
		Project = new ProjectService().getProjectById(ProjectNo);
		return Response.ok(200).entity(MyBaticsUtill.ConvertJavaObject2Json(Project)).build();
	}

	@GET
	@Path("/{managerId}/allProjects")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response getAllProjectsByManager(@PathParam("managerId") int managerId) {
		List<Project> project = new ProjectService().getAllProjectByManagerId(managerId);
		return Response.ok(200).entity(MyBaticsUtill.ConvertJavaObject2Json(project)).build();
	}

	@POST
	@Path("/Insert")
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response insertProject(Project Project) {
		new ProjectService().insertProject(Project);
		return Response.ok(201).entity("Insert:" + Project.toString() + " ---------Successfully Inserted----------- ")
				.build();
	}

	@DELETE
	@Path("/DELETE/{id}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response deleteProject(@PathParam("id") String _project) {
		Project Deleted = new ProjectService().getProjectById(_project);
		new ProjectService().deleteProject(_project);
		return Response.ok(200).entity("Deleted:" + Deleted.toString() + " ---------Successfully Deleted----------- ")
				.build();
	}

	@PUT
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("/UPDATE/{Project}")
	public Response updateProject(Project Project) {
		System.out.println(Project);
		new ProjectService().updateProject(Project);
		return Response.status(200).entity("Sucessfully Updated the Details " + Project.toString()).build();
	}

	@GET
	@Path("/cool")
	@Produces(MediaType.TEXT_HTML)
	public String goodmoring() {
		return "This is project file";
	}
}