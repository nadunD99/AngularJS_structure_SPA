package com.webservice.rest.service;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.webservice.rest.mapping.EmployeeMapper;
import com.webservice.rest.mapping.ProjectMapper;
import com.webservice.rest.mapping.ServiceMapper;
import com.webservice.rest.model.Employee;
import com.webservice.rest.model.Project;
import com.webservice.rest.utill.MyBaticsUtill;

public class EmployeeService implements EmployeeMapper {

	@Override
	public List<Employee> getAllEmployees() {
		List<Employee> employees = new ArrayList();
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			EmployeeMapper mapper = session.getMapper(EmployeeMapper.class);
			employees = mapper.getAllEmployees();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return employees;
	}

	@Override
	public Employee getEmployeeById(int employee) {
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		Employee emp = new Employee();
		try {
			EmployeeMapper mapper = session.getMapper(EmployeeMapper.class);
			emp = mapper.getEmployeeById(employee);
		} finally {
			session.close();
		}
		return emp;
	}

	@Override
	public void deleteEmployee(int employee) {
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			EmployeeMapper mapper = session.getMapper(EmployeeMapper.class);
			mapper.deleteEmployee(employee);
			session.commit();
		} finally {
			session.close();
		}
	}

	@Override
	public void insertEmployee(Employee employee) {
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			EmployeeMapper mapper = session.getMapper(EmployeeMapper.class);
			mapper.insertEmployee(employee);
			session.commit();
		} finally {
			session.close();
		}
	}

	@Override
	public void updateEmployee(Employee employee) {
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			EmployeeMapper mapper = session.getMapper(EmployeeMapper.class);
			mapper.updateEmployee(employee);
			session.commit();
		} finally {
			session.close();
		}

	}

	@Override
	public List<Employee> getAllEmployeeInProject(String ProjectId) {
		List<Employee> Emp_List = new ArrayList();
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			EmployeeMapper mapper = session.getMapper(EmployeeMapper.class);
			Emp_List = mapper.getAllEmployeeInProject(ProjectId);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return Emp_List;
	}
	
	public List<Employee> getSumSalariesOnProject() {
		List<Employee> Emp_List = new ArrayList();
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		EmployeeMapper mapper = session.getMapper(EmployeeMapper.class);
		Emp_List  =  mapper.getSumSalariesOnProject();
		return Emp_List ;
	}

}
