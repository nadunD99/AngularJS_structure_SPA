package com.webservice.rest.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.webservice.rest.mapping.ProjectManagerMapper;
import com.webservice.rest.model.Employee;
import com.webservice.rest.model.ProjectManager;
import com.webservice.rest.utill.MyBaticsUtill;

public class ProjectManagerService implements ProjectManagerMapper {

	@Override
	public List<ProjectManager> getAllManagers() {
		List<ProjectManager> projectManagers = new ArrayList();
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			ProjectManagerMapper mapper = session.getMapper(ProjectManagerMapper.class);
			projectManagers = mapper.getAllManagers();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return projectManagers;
	}

	@Override
	public ProjectManager getManagerById(int manager) {
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		ProjectManager yu = new ProjectManager();
		try {
			ProjectManagerMapper mapper = session.getMapper(ProjectManagerMapper.class);
			yu = mapper.getManagerById(manager);
		} finally {
			session.close();
		}
		return yu;
	}

	@Override
	public void deleteManager(int manager) {
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			ProjectManagerMapper mapper = session.getMapper(ProjectManagerMapper.class);
			mapper.deleteManager(manager);
			session.commit();
		} finally {
			session.close();
		}
	}

	@Override
	public void insertManager(ProjectManager manager) {
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			ProjectManagerMapper mapper = session.getMapper(ProjectManagerMapper.class);
			mapper.insertManager(manager);
			session.commit();
		} finally {
			session.close();
		}
	}

	@Override
	public void updateManager(ProjectManager manager) {
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			ProjectManagerMapper mapper = session.getMapper(ProjectManagerMapper.class);
			mapper.updateManager(manager);
			session.commit();
		} finally {
			session.close();
		}
	}

	@Override
	public List<Employee> getEmployeeByManagerId(int manager) {
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		List<Employee> ManagerMapToEmp = new ArrayList();
		try {
			ProjectManagerMapper mapper = session.getMapper(ProjectManagerMapper.class);
			ManagerMapToEmp =  mapper.getEmployeeByManagerId(manager);
		} finally {
			session.close();
		}
		return ManagerMapToEmp;
	}
}
