package com.webservice.rest.service;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.webservice.rest.mapping.ServiceMapper;
import com.webservice.rest.model.Employee;
import com.webservice.rest.utill.MyBaticsUtill;

public class Service implements ServiceMapper {

	@Override
	public List<Employee> getSumSalariesOnProject() {
		List<Employee> Result = new ArrayList();
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		ServiceMapper mapper = session.getMapper(ServiceMapper.class);
		Result  = mapper.getSumSalariesOnProject();
		return Result ;
	}
	
	
	
	
//	@Override
//	public ResultSet getSumSalariesOnProject() {
//		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
//		
//			ServiceMapper mapper = session.getMapper(ServiceMapper.class);
//			 ResultSet rs  = mapper.getSumSalariesOnProject();
//				
//		return rs ;
//	}
}
