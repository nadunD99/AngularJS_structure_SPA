package com.webservice.rest.controller;

import java.util.List;

import javax.validation.Valid;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.webservice.rest.model.Employee;
import com.webservice.rest.model.ProjectManager;
import com.webservice.rest.service.ProjectManagerService;
import com.webservice.rest.utill.MyBaticsUtill;

@Path("/manager")
public class ManagerController {

	@GET
	@Path("/all")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response getAllProjectManagers() {
		List<ProjectManager> managers = new ProjectManagerService().getAllManagers();
		//return Response.ok(200).entity(managers.toString()).build();
		return Response.ok(200).entity(MyBaticsUtill.ConvertJavaObject2Json(managers)).build();
	}

	@GET
	@Valid
	@Path("/{ManagerNo}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response getManagerOnId(@PathParam("ManagerNo") int ManagerNo) {
		ProjectManager projectManager = new ProjectManager();
		projectManager = new ProjectManagerService().getManagerById(ManagerNo);
		return Response.ok(200).entity(MyBaticsUtill.ConvertJavaObject2Json(projectManager)).build();
	}

	// Take employees based on managerid
	@GET
	@Valid
	@Path("/getEmployees/{ManagerNo}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response getEmployeesByManagerOId(@PathParam("ManagerNo") int ManagerNo) {
		List<Employee> emp_PM = new ProjectManagerService().getEmployeeByManagerId(ManagerNo);
		return Response.ok(200).entity(MyBaticsUtill.ConvertJavaObject2Json(emp_PM)).build();
	}

	@POST
	@Path("/Insert")
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response insertManager(@Valid ProjectManager manager) {
		new ProjectManagerService().insertManager(manager);
		return Response.ok(201).entity("Insert:" + manager.toString() + " ---------Successfully Inserted----------- ")
				.build();
	}

	@DELETE
	@Valid
	@Path("/DELETE/{id}")
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public Response deleteManager(@PathParam("id") int userId) {
		ProjectManager Deleted = new ProjectManagerService().getManagerById(userId);
		new ProjectManagerService().deleteManager(userId);
		return Response.ok(200).entity("Deleted:" + Deleted.toString() + " ---------Successfully Deleted----------- ")
				.build();
	}

	@PUT
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Consumes({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("/UPDATE/{manager}")
	public Response updateProjectManager(@Valid ProjectManager manager) {
		new ProjectManagerService().updateManager(manager);
		return Response.status(200).entity("Sucessfully Updated the Details " + manager.toString()).build();
	}

	@GET
	@Path("/cool")
	@Produces(MediaType.TEXT_HTML)
	public String goodmoring() {
		return "Good Morning";
	}

	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	@Path("/exception")
	@Valid
	public ProjectManager exception() {
		ProjectManager P101 = new ProjectManager();
		P101.setName("Kalum ekanayake");
		P101.setEmail("Kalum@you.com");
		P101.setContact_number("078596231");
		return P101;
	}
}
