package com.webservice.rest.Testing;

import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Assert;

import com.webservice.rest.model.ProjectManager;
import com.webservice.rest.service.ProjectManagerService;

public class ProjectManagerTest {
	private static ProjectManagerService ManagerService;

	@BeforeClass
	public static void setup() {
		ManagerService = new ProjectManagerService();
	}

	@AfterClass
	public static void teardown() {
		ManagerService = null;
	}

	@Test
	public void testGetManagerById() {
		ProjectManager M = ManagerService.getManagerById(5);
		Assert.assertNotNull(M);
		System.out.println(M);
	}

	@Test
	public void testGetAllManagers() {
		List<ProjectManager> All = ManagerService.getAllManagers();
		Assert.assertNotNull(All);
		for (ProjectManager M : All) {
			System.out.println(All);
		}
	}

	@Test
	public void testInsertManager() {
		ProjectManager manager = new ProjectManager();
		manager.setName("kulathunga");
		manager.setEmail("kulathunga@gmail.com");
		manager.setContact_number("0761414569");
		ManagerService.insertManager(manager);
		Assert.assertTrue(manager.getId() != 0);
		ProjectManager createdM = ManagerService.getManagerById(manager.getId());
		Assert.assertNotNull(createdM);
		Assert.assertEquals(manager.getId(), createdM.getId());
		Assert.assertEquals(manager.getName(), createdM.getName());
		Assert.assertEquals(manager.getEmail(), createdM.getEmail());
		Assert.assertEquals(manager.getContact_number(), createdM.getContact_number());
		System.out.println(createdM.toString());
	}

	@Test
	public void testUpdateManager() {
		ProjectManager manager = ManagerService.getManagerById(12);
		System.out.println("Before update : " + manager.toString());
		manager.setName("Koliya");
		manager.setEmail("KoliyabANDA@YMAIL.COM");
		ManagerService.updateManager(manager);
		// After Update
		ProjectManager updatedManager = ManagerService.getManagerById(12);
		Assert.assertEquals(manager.getName(), updatedManager.getName());
		Assert.assertEquals(manager.getEmail(), updatedManager.getEmail());
		System.out.println("Before update : " + updatedManager.toString());
	}

	@Test
	public void testDeleteManager() {
		ProjectManager manager = ManagerService.getManagerById(5);
		ManagerService.deleteManager(manager.getId());
		System.out.println("DELETED---> " + manager.toString());
		ProjectManager deletedManager = ManagerService.getManagerById(5);
		Assert.assertNull(deletedManager);
		System.out.println(ManagerService.getAllManagers());
	}
}
