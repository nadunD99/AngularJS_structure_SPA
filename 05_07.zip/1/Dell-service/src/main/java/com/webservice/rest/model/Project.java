package com.webservice.rest.model;

public class Project {

	private String project_id;
	private String project_name;
	private String project_location;
	private Integer pmanager_id;

	// constructors
	public Project() {
	}

	public Project(String project_id, String project_name, String project_location, Integer pmanager_id) {
		super();
		this.project_id = project_id;
		this.project_name = project_name;
		this.project_location = project_location;
		this.pmanager_id = pmanager_id;
	}

	// Getters ans Setters
	public String getProject_id() {
		return project_id;
	}

	public void setProject_id(String project_id) {
		this.project_id = project_id;
	}

	public String getProject_name() {
		return project_name;
	}

	public void setProject_name(String project_name) {
		this.project_name = project_name;
	}

	public String getProject_location() {
		return project_location;
	}

	public void setProject_location(String project_location) {
		this.project_location = project_location;
	}

	public Integer getPManager_id() {
		return pmanager_id;
	}

	public void setPManager_id(Integer pmanager_id) {
		this.pmanager_id = pmanager_id;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Project [project_id=").append(project_id).append(", project_name=").append(project_name)
				.append(", project_location=").append(project_location).append(", pmanager_id=").append(pmanager_id)
				.append("]");
		return builder.toString();
	}

	

}