package com.webservice.rest.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.webservice.rest.mapping.ProjectMapper;
import com.webservice.rest.model.Project;
import com.webservice.rest.utill.MyBaticsUtill;

public class ProjectService implements ProjectMapper {

	@Override
	public List<Project> getAllProjects() {
		List<Project> project = new ArrayList();
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			ProjectMapper mapper = session.getMapper(ProjectMapper.class);
			project = mapper.getAllProjects();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return project;
	}

	@Override
	public void deleteProject(String Project) {
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			ProjectMapper mapper = session.getMapper(ProjectMapper.class);
			mapper.deleteProject(Project);
			session.commit();
		} finally {
			session.close();
		}
	}

	@Override
	public void insertProject(Project project) {
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			ProjectMapper mapper = session.getMapper(ProjectMapper.class);
			mapper.insertProject(project);
			session.commit();
		} finally {
			session.close();
		}
	}

	@Override
	public void updateProject(Project project) {
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			ProjectMapper mapper = session.getMapper(ProjectMapper.class);
			mapper.updateProject(project);
			session.commit();
		} finally {
			session.close();
		}
	}

	@Override
	public Project getProjectById(String Project) {
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		Project _project = new Project();
		try {
			ProjectMapper mapper = session.getMapper(ProjectMapper.class);
			_project = mapper.getProjectById(Project);
		} finally {
			session.close();
		}
		return _project;
	}

	@Override
	public List<Project> getAllProjectByManagerId(int managerID) {
		List<Project> project = new ArrayList();
		SqlSession session = MyBaticsUtill.getSqlSessionFactory().openSession();
		try {
			ProjectMapper mapper = session.getMapper(ProjectMapper.class);
			project = mapper.getAllProjectByManagerId(managerID);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			session.close();
		}
		return project;
	}
}
