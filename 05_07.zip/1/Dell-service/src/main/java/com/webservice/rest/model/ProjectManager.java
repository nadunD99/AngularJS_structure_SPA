package com.webservice.rest.model;

import java.io.Serializable;

public class ProjectManager implements Serializable {

	private int id;
	private String name;
	private String email;
	private String contact_number;

	// Constructors
	public ProjectManager() {
	}

	public ProjectManager(int id, String name, String email, String contact_number) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.contact_number = contact_number;
	}

	public ProjectManager(String name, String email, String contact_number) {
		super();
		this.name = name;
		this.email = email;
		this.contact_number = contact_number;
	}

	// Getters and Setters
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContact_number() {
		return contact_number;
	}

	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ProjectManager [id=").append(id).append(", name=").append(name).append(", email=").append(email)
				.append(", contact_number=").append(contact_number).append("]");
		return builder.toString();
	}

	
}
