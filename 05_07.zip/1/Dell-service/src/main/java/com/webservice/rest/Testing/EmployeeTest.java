package com.webservice.rest.Testing;

import java.util.List;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Assert;

import com.webservice.rest.model.Employee;
import com.webservice.rest.model.ProjectManager;
import com.webservice.rest.service.EmployeeService;

public class EmployeeTest {
	private static EmployeeService employeeService;

	@BeforeClass
	public static void setup() {
		employeeService = new EmployeeService();
	}

	@AfterClass
	public static void teardown() {
		employeeService = null;
	}

	@Test
	public void testGetEmployeeById() {
		Employee E = employeeService.getEmployeeById(500002);
		Assert.assertNotNull(E);
		System.out.println(E);
	}

	@Test
	public void testGetAllEmployees() {
		List<Employee> All = employeeService.getAllEmployees();
		Assert.assertNotNull(All);
		for (Employee E : All) {
			System.out.println(All);
		}
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testInsertEmployee() {
		Employee employee = new Employee();
		employee.setEmp_name("Shiro Romesh");
		employee.setEmp_email("Shiroma@gmail.com");
		employee.setProject_id("CMB09V56");
		employee.setEmp_salary(55890.00);
		employeeService.insertEmployee(employee);
		Assert.assertTrue(employee.getEmp_id() != 0);
		Employee createdE = employeeService.getEmployeeById(employee.getEmp_id());
		Assert.assertNotNull(createdE);
		Assert.assertEquals(employee.getEmp_name(), createdE.getEmp_name());
		Assert.assertEquals(employee.getEmp_salary(), createdE.getEmp_salary(), 2);
		Assert.assertEquals(employee.getProject_id(), createdE.getProject_id());
		Assert.assertEquals(employee.getEmp_email(), createdE.getEmp_email());
		System.out.println(createdE.toString());
	}

	@Test
	public void testUpdateEmployee() {

		Employee employee = employeeService.getEmployeeById(500006);
		System.out.println("Before update : " + employee.toString());
		employee.setEmp_name("Thanuja Senaka");
		employee.setEmp_email("TSkhan@gmail.com");
		employee.setEmp_salary(60890.00);
		employeeService.updateEmployee(employee);
		// After Update
		Employee updatedEmployee = employeeService.getEmployeeById(500006);
		Assert.assertEquals(employee.getEmp_name(), updatedEmployee.getEmp_name());
		Assert.assertEquals(employee.getEmp_email(), updatedEmployee.getEmp_email());
		Assert.assertEquals(employee.getEmp_salary(), updatedEmployee.getEmp_salary(), 2);
		System.out.println("Before update : " + updatedEmployee.toString());
	}

	@Test
	public void testDeleteEmployee() {
		Employee employee = employeeService.getEmployeeById(500006);
		employeeService.deleteEmployee(employee.getEmp_id());
		System.out.println("DELETED---> " + employee.toString());
		Employee deletedEmployee = employeeService.getEmployeeById(500006);
		Assert.assertNull(deletedEmployee);
		System.out.println(employeeService.getAllEmployees());
	}
}