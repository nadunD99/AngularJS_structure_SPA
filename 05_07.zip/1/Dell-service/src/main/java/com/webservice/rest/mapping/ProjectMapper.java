package com.webservice.rest.mapping;

import java.util.List;

import com.webservice.rest.model.Project;

public interface ProjectMapper {

	public List<Project> getAllProjects();

	public Project getProjectById(String Project);

	public void deleteProject(String Project);

	public void insertProject(Project project);

	public void updateProject(Project project);

	public List<Project> getAllProjectByManagerId(int managerID);
}