package com.webservice.rest.model;

public class ProjectManager {
	
		 
	    private Integer PMid;
	    private String name;
	    private String email;
	    private String contact_number;
		
	    public ProjectManager(){}
	    
	    //Constructors
	    public ProjectManager(Integer pMid, String name, String email, String contact_number) {
			super();
			PMid = pMid;
			this.name = name;
			this.email = email;
			this.contact_number = contact_number;
		}
	    
	    
	    //Getters and Setters
	    public Integer getPMid() {
			return PMid;
		}
		
		public void setPMid(Integer pMid) {
			PMid = pMid;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getContact_number() {
			return contact_number;
		}
		public void setContact_number(String contact_number) {
			this.contact_number = contact_number;
		}

		@Override
		public String toString() {
			return "ProjectManager [PMid=" + PMid + ", name=" + name + ", email=" + email + ", contact_number="
					+ contact_number + "]";
		}
	    
		
	    
	 
}
