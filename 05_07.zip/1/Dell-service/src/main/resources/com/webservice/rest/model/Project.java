package com.webservice.rest.model;

public class Project {
	
	 	private Integer Project_id;
	    private String P_name;
	    private String ProjectLocation;
	    private Integer PManager_id;
		
	    //constructors
	    public Project() {}
	    	    
	    public Project(Integer project_id, String p_name, String projectLocation, Integer pManager_id) {
			super();
			Project_id = project_id;
			P_name = p_name;
			ProjectLocation = projectLocation;
			PManager_id = pManager_id;
		}

	    
	    //Getters and setters
		public Integer getProject_id() {
			return Project_id;
		}


		public void setProject_id(Integer project_id) {
			Project_id = project_id;
		}


		public String getP_name() {
			return P_name;
		}


		public void setP_name(String p_name) {
			P_name = p_name;
		}


		public String getProjectLocation() {
			return ProjectLocation;
		}


		public void setProjectLocation(String projectLocation) {
			ProjectLocation = projectLocation;
		}


		public Integer getPManager_id() {
			return PManager_id;
		}


		public void setPManager_id(Integer pManager_id) {
			PManager_id = pManager_id;
		}
	    
		
	    
	    
	    

}
