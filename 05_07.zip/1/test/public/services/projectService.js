myApp.factory('projectService',['$http', function ($http) {
    return {
        get : function () {
            return $http.get('http://localhost:8080/Dell-service/webapi/projects/allProjects').then(function (res) {
            return res.data;
            });
        },

        update: function(project_id,uproject) {
            console.log("service "+uproject);
            return $http.put('http://localhost:8080/Dell-service/webapi/projects/UPDATE/'+project_id,uproject).then(function(res) {
            return res.data;
            });
          }
        }
    }]);