myApp.factory('projectManagerService',['$http', function ($http) {
    return {
        get : function () {
            return $http.get('http://localhost:8080/Dell-service/webapi/manager/all').then(function (res) {
            console.log(res);    
            return res.data;
            });
        },
    };
}]);