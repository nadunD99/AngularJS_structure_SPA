myApp.factory('EmpService',['$http', function ($http) {
    return {
        get : function () {
            return $http.get('http://localhost:8080/Dell-service/webapi/employee/getAllEmployee').then(function (res) {
            // console.log(res.data);    
            return res.data;
            });
        },
        add : function(Employee){
            return $http.post('http://localhost:8080/Dell-service/webapi/employee/addEmployee',Employee).then(function(res) {
            return res.data;
            })
        },
        update: function(nEmployee) {
            console.log("service "+nEmployee);
            return $http.put('http://localhost:8080/Dell-service/webapi/employee/UPDATE/'+nEmployee.emp_id,nEmployee).then(function(res) {
            return res.data;
            });
          },

        delete: function(employee) {
            return $http.delete('http://localhost:8080/Dell-service/webapi/employee/DELETE/'+employee.emp_id,employee).then(function(res) {
            return res.data;
            });
          }
        }
    
}]);