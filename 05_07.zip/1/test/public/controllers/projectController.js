myApp.controller('projectController', ['$scope', 'projectService', function ($scope, projectService) {

    $scope.uproject = {};
    function getProjects() {
        projectService.get().then(function (projects) {

            $scope.projects = projects;

        })
    };

    getProjects();

    $scope.editProject = function (project) {
        $scope.uproject = project
    }

    $scope.UpdateProject = function (project_id, uproject) {
        projectService.update(project_id, uproject).then(function (data) {
            if (data.success) {
                alert("Successfully updated");
                getProject();
            } else {
                alert("Error");
            }
        })
    };


}]);