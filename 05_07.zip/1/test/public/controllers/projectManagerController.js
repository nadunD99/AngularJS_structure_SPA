myApp.controller('projectManagerController', ['$scope',  'projectManagerService', function ($scope, projectManagerService) {
    $scope.nManager = {};
    function getProjectManagers() {
        projectManagerService.get().then(function (managers) {
          
            $scope.managers = managers;
        })
    };

    getProjectManagers();

    $scope.editProjectManager = function (manager) {
        $scope.nManager = manager
    }
}]);