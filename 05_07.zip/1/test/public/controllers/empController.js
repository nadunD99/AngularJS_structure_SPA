myApp.controller('EmpController', ['$scope',  'EmpService', function ($scope, EmpService) {
    $scope.nEmployee={};
    function getEmployees() {
        EmpService.get().then(function (employees) {
          
            $scope.employees = employees;
        })
    };

    getEmployees();


    $scope.addEmployee= function (employee) {
        EmpService.add(employee).then(function (data) {
            if(data.success){
                alert("Successfully added");
                getCategory();
                
            }else{
                alert("Error");
            }

        })
    };

    $scope.editEmployee = function (employee) {
        $scope.nEmployee = employee
         }

     $scope.UpdateEmployee = function (nEmployee) {
     EmpService.update(nEmployee).then(function (data) {
         if(data.success){
             alert("Successfully updated");
             getEmployees();
         }else{
             alert("Error");
         }
     })
    };

    $scope.Delete = function (employee) {
        var result = confirm("Are you sure ?");
        if (result == true){
            EmpService.delete(employee).then(function (data) {
                if (data.success) {
                    getEmployees();
                    alert("Successfully deleted");
                }
            })
    }
    };



}]);