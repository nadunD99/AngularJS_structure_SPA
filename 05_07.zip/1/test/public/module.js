var myApp = angular.module("myApp", ["ngRoute"]);
myApp.config(function($routeProvider) {
    $routeProvider
    .when("/", {
        templateUrl : "./views/main.html"
    })
    .when("/red", {
        templateUrl : "./views/red.html"
    })
    .when("/green", {
        templateUrl : "./views/green.html"
    })
    .when("/blue", {
        templateUrl : "./views/blue.html"
    })
    .when("/emp", {
        templateUrl : "./views/employee.html"
    })
    .when("/AddNewEmp", {
        templateUrl : "./views/AddEmployee.html"
    })
    .when("/project", {
        templateUrl : "./views/project.html"
    })
    .when("/Manager", {
        templateUrl : "./views/projectManager.html"
    });
});